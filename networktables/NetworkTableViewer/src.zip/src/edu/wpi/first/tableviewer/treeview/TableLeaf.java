/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.tableviewer.treeview;

import edu.wpi.first.wpilibj.tables.ITable;

/**
 *
 * @author Sam
 */
public class TableLeaf extends ITableItem {

    // default to an unknown type
    private final ITable table;
    private EntryType type = EntryType.UNSUPPORTED;
    private String key;
    private Object value;

    public enum EntryType {

        BOOLEAN, NUMBER, STRING, UNSUPPORTED
    }

    public TableLeaf(ITable table, String key, Object value) {
        super();
        this.table = table;
        this.key = key;
        this.value = value;
        String valueClass = value.getClass().toString();
        String valueClassName = valueClass.substring(valueClass.lastIndexOf(".") + 1);
        switch (valueClassName.toLowerCase()) {
            case "boolean":
                type = EntryType.BOOLEAN;
                break;
            case "double":
                type = EntryType.NUMBER;
                break;
            case "string":
                type = EntryType.STRING;
                break;
            default:
                type = EntryType.UNSUPPORTED;
                break;
        }
        setValue(this);
    }
    
    public ITable getTable() {
        return table;
    }

    public String getTableKey() {
        return key;
    }
    
    public Object getTableValue() {
        return value;
    }
    
    /**
     * Sets the display value of this TableLeaf to a new value.
     *
     * @param newValue The new value of this entry.
     */
    public void setTableValue(Object newValue) {
        this.value = newValue;
        // very hackish, but it works so this'll update with external and internal changes
        setValue(this);
        setValue(new TableLeaf(table, key, value));
    }
    
    /**
     * Updates the value in this TableLeaf's ITable and updates the displayed
     * value.
     * 
     * @param newValue The new value of this entry.
     * @see #setTableValue
     */
    public void update(Object newValue) {
        setTableValue(newValue);
        table.putValue(key, value);
    }

    public EntryType getType() {
        return type;
    }

    @Override
    public String toString() {
        return key + " = " + value;
    }

    @Override
    public boolean isLeaf() {
        return true;
    }
}
