/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.tableviewer.treeview;

import edu.wpi.first.tableviewer.popup.PopupFactory;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TreeCell;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author Sam
 */
public class TableTreeCell extends TreeCell<ITableItem> {

    public TableTreeCell() {
        super();
        this.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent t) {
                ITableItem selected = getItem();
                if (selected instanceof TableLeaf && t.getClickCount() == 2) {
                    PopupFactory.showEditorDialog((TableLeaf) selected);
                }
            }
        });
    }

    @Override
    public void updateItem(ITableItem tableItem, boolean empty) {
        super.updateItem(tableItem, empty);
        if (tableItem != null && !empty) {
            if (tableItem instanceof TableBranch) {
                setContextMenu(getBranchMenu((TableBranch) tableItem));
                setText(tableItem.toString());
            } else if (tableItem instanceof TableLeaf) {
                setContextMenu(getLeafMenu((TableLeaf) tableItem));
                setText(tableItem.toString());
            }
        }
    }

    private ContextMenu getBranchMenu(final TableBranch branch) {
        MenuItem addBoolean = new MenuItem("Add boolean");
        MenuItem addNumber = new MenuItem("Add number");
        MenuItem addString = new MenuItem("Add string");

        addBoolean.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                PopupFactory.showAddBooleanDialog(branch.getTable());
            }
        });

        addNumber.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                PopupFactory.showAddNumberDialog(branch.getTable());
            }
        });

        addString.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                PopupFactory.showAddStringDialog(branch.getTable());
            }
        });

        ContextMenu cMenu = new ContextMenu();
        cMenu.getItems().addAll(addBoolean, addNumber, addString);
        return cMenu;
    }

    private ContextMenu getLeafMenu(final TableLeaf leaf) {
        MenuItem edit = new MenuItem("Edit");

        edit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                PopupFactory.showEditorDialog(leaf);
            }
        });

        ContextMenu cMenu = new ContextMenu(edit);
        return cMenu;

    }
}
